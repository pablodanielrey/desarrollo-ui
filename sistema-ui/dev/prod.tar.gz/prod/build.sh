#!/bin/bash
sudo docker build -t assistance-ui-prod -f docker/dockerfile .
